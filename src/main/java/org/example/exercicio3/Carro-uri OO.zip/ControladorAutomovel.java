package org.example;

public interface ControladorAutomovel {

    public abstract void ligar();
    public abstract void desligar();
    public abstract void acelerar();
    public abstract void freiar();
    public abstract void buzinar();

}
