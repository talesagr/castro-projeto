package org.example;

public class Main {
    public static void main(String[] args) {
        Carro meuCarro = new Carro();
        meuCarro.ligar();
        meuCarro.acelerar();
        meuCarro.buzinar();
        meuCarro.buzinar();
        meuCarro.buzinar();
        meuCarro.freiar();
        meuCarro.desligar();
    }
}