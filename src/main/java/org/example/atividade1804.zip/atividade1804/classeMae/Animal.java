package org.example.atividade1804.classeMae;

public abstract class Animal{

    public Double peso;
    public int idade;
    public int membros;


    public abstract void locomover();

    public abstract void alimentar();

    public abstract void emitirSom();
}
