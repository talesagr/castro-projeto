package org.example.atividade1804.classeMae.Filhos.Netos;

import org.example.atividade1804.classeMae.Filhos.Peixe;

public class Goldfish extends Peixe {
}
