package org.example.atividade1804.classeMae.Filhos;

import org.example.atividade1804.classeMae.Animal;

public class Reptil extends Animal {
   public String corEscama;

   @Override
   public void locomover() {

   }

   @Override
   public void alimentar() {

   }

   @Override
   public void emitirSom() {

   }
}
